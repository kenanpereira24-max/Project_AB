const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const dbURI =
  "mongodb+srv://User:12345@cluster0.nkifvrg.mongodb.net/myDatabaseName?retryWrites=true&w=majority&appName=Cluster0";

mongoose.connect(dbURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const contactSchema = new mongoose.Schema({
  name: String,
  email: String,
  message: String,
  submittedAt: { type: Date, default: Date.now },
});

const donateSchema = new mongoose.Schema({
  name: String,
  email: String,
  amount: Number,
  paymentStatus: String,
  submittedAt: { type: Date, default: Date.now },
});

const Contact = mongoose.model("Contact", contactSchema);
const Donate = mongoose.model("Donate", donateSchema);

app.post("/contact", async (req, res) => {
  try {
    const newContact = new Contact({
      name: req.body.name,
      email: req.body.email,
      message: req.body.message,
    });

    await newContact.save();
    res.status(200).send("Contact form submitted successfully");
  } catch (error) {
    res.status(500).send("Error saving contact data");
  }
});

app.post("/donate", async (req, res) => {
  try {
    const newDonation = new Donate({
      name: req.body.name,
      email: req.body.email,
      amount: req.body.amount,
      paymentStatus: "Pending",
    });

    await newDonation.save();
    res.status(200).send("Donation recorded successfully");
  } catch (error) {
    res.status(500).send("Error saving donation data");
  }
});

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
